# Power BI — Weeks 5 & 6

## Week 5 Transaction page
Use `results/week5_transactions.csv`.

KPIs:
- Transaction count
- Commit rate
- Abort rate
- In-doubt transactions
- Average transaction latency
- Average prepare time
- Average commit time

Visuals:
- Transaction status donut
- Transaction latency by transaction ID
- Prepare vs commit duration
- Rating-node transaction distribution
- Failure/abort table

## Week 6 Concurrency page
Use `results/week6_concurrency.csv`.

KPIs:
- Concurrent transactions
- Completed operations
- Deadlock detections
- Contention time

Visuals:
- Transaction result by operation
- Duration by transaction
- Deadlock detection count
- Resource contention table


