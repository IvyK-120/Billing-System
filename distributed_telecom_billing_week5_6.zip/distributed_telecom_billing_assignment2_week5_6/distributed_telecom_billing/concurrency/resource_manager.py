import threading
import time
from collections import defaultdict


class ResourceManager:
    """Resource manager with wait-for graph and deadlock detection."""

    def __init__(self):
        self.locks = defaultdict(threading.Lock)
        self.waiting = defaultdict(set)
        self.owner = {}
        self.meta_lock = threading.Lock()

    def acquire(self, txid, resource, timeout=1.0):
        """
        Attempt to acquire a resource while maintaining
        wait-for graph information.
        """

        start = time.perf_counter()

        with self.meta_lock:
            self.waiting[txid].add(resource)

        # Poll instead of blocking for the entire timeout.
        # This allows the experiment to detect a deadlock
        # while both transactions are still waiting.
        while time.perf_counter() - start < timeout:

            acquired = self.locks[resource].acquire(blocking=False)

            if acquired:
                with self.meta_lock:
                    self.waiting[txid].discard(resource)
                    self.owner[resource] = txid

                return True

            time.sleep(0.01)

        with self.meta_lock:
            self.waiting[txid].discard(resource)

        return False

    def release(self, txid, resource):
        with self.meta_lock:
            if self.owner.get(resource) == txid:
                self.owner.pop(resource, None)

        try:
            self.locks[resource].release()
        except RuntimeError:
            pass

    def wait_for_graph(self):
        """
        Build graph:

        transaction -> transaction holding requested resource
        """

        graph = {}

        with self.meta_lock:
            for tx, resources in self.waiting.items():

                for resource in resources:

                    holder = self.owner.get(resource)

                    if holder and holder != tx:
                        graph.setdefault(tx, set()).add(holder)

        return graph

    @staticmethod
    def has_cycle(graph):
        """Detect a cycle in the wait-for graph."""

        visiting = set()
        visited = set()

        def dfs(node):

            if node in visiting:
                return True

            if node in visited:
                return False

            visiting.add(node)

            for nxt in graph.get(node, ()):
                if dfs(nxt):
                    return True

            visiting.remove(node)
            visited.add(node)

            return False

        return any(dfs(node) for node in graph)