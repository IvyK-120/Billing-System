# Assignment 2 — Weeks 5 & 6
## Distributed Telecom Billing and Rating System

### Week 5 — Distributed Transactions
The system adds a Two-Phase Commit transaction layer. Node 2 is the coordinator. A rating node and the distributed ledger are participants.

Flow:
Client → Apache → Billing API → Node 2 Coordinator → PREPARE Rating + PREPARE Ledger → COMMIT Rating + COMMIT Ledger

Measurements:
- Transaction latency
- Throughput
- Failure/abort behavior
- Consistency
- Availability
- Prepare and commit overhead

### Week 6 — Concurrency and Deadlock
The system models concurrent billing/settlement processes competing for account resources. A resource manager records resource ownership and waiting relationships and constructs a wait-for graph. A cycle is used to detect deadlock.

The next implementation stage can add ordered locking as a prevention mechanism and compare it with the deliberately deadlocking baseline.

### Required experimental method
Hypothesis → Experimental Design → Implementation → Measurement → Analysis → Conclusion

### Assignment brief alignment
Week 5 requires ACID properties, 2PC/3PC or simulation, distributed recovery and evaluation of transaction latency, throughput, failure behavior, consistency and availability. Week 6 requires concurrent execution, race conditions, mutual exclusion, deadlock, starvation/resource contention and deadlock detection/prevention/recovery.
