# Week 5 — Failure-Driven Engineering Log

## What changed?
The billing system was extended with a distributed transaction subsystem using Two-Phase Commit (2PC). Node 2 acts as transaction coordinator. A selected rating node and a separate ledger process act as transaction participants.

## What failed / was considered?
A direct write to distributed state without coordination could leave one participant updated while another failed. This was treated as an atomicity risk.

## Why?
The rating result and ledger update occur in separate processes. A failure between the two operations can create inconsistent billing state.

## How was it fixed?
The transaction was divided into PREPARE and COMMIT phases. Participants first prepare the transaction and only commit after all required participants acknowledge PREPARE. Failed preparation triggers ABORT. An uncertain commit is recorded as `IN_DOUBT` rather than falsely reported as successful.

## Alternative considered
A single-node database transaction was considered, but it would remove the distributed transaction problem required by Week 5.

## What was learned?
2PC improves consistency across distributed participants but introduces additional messages, latency, and coordinator dependency.
