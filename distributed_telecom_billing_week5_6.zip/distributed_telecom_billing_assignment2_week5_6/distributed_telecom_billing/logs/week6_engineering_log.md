# Week 6 — Failure-Driven Engineering Log

## What changed?
Concurrent billing/settlement operations were modelled as processes competing for distributed account resources. A resource manager tracks ownership and waiting relationships.

## What failed?
Two concurrent operations can acquire different resources and then wait for each other's resource, producing a circular wait.

## Why?
The transactions acquire resources in different orders. This creates the classic deadlock condition of circular wait.

## How was it detected?
A wait-for graph is constructed from the resource ownership and waiting state. A cycle indicates a deadlock.

## Recovery / prevention direction
The current experiment demonstrates detection. The next refinement is ordered resource acquisition (for example, always acquire the lower account identifier first), which prevents circular wait.

## Alternative considered
A simple global lock was considered, but it would reduce concurrency and hide the distributed resource-contention problem.

## What was learned?
Concurrency improves utilization but introduces race conditions, contention, starvation and deadlock risks. Distributed systems therefore need explicit synchronization and deadlock handling.
