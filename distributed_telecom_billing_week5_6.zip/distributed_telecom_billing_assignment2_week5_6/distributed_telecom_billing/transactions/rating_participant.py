import threading

class RatingTransactionParticipant:
    """Local transaction state for a rating node used by Week 5 2PC."""
    def __init__(self, engine):
        self.engine=engine
        self.prepared={}
        self.committed={}
        self._lock=threading.Lock()

    def prepare(self, request):
        tx=request["transaction_id"]
        with self._lock:
            if tx in self.committed:
                return {"prepared":True,"charge":self.committed[tx]["charge"],"already_committed":True}
            charge=self.engine.calculate_charge(request["service"],request["usage"])
            self.prepared[tx]={"charge":charge,"request":dict(request)}
            return {"prepared":True,"transaction_id":tx,"charge":charge}

    def commit(self, tx):
        with self._lock:
            if tx in self.committed: return {"committed":True,"already_committed":True}
            if tx not in self.prepared: return {"committed":False,"error":"transaction not prepared"}
            self.committed[tx]=self.prepared.pop(tx)
            return {"committed":True,"transaction_id":tx}

    def abort(self, tx):
        with self._lock: self.prepared.pop(tx,None)
        return {"aborted":True,"transaction_id":tx}
