import json, os, socket, sys, threading, time
PROJECT_ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path: sys.path.insert(0, PROJECT_ROOT)
from common.config import LEDGER_HOST, LEDGER_PORT

class Ledger:
    def __init__(self):
        self.prepared={}; self.committed={}; self._lock=threading.Lock()
    def prepare(self, req):
        with self._lock:
            tx=req["transaction_id"]
            if tx in self.committed: return {"prepared":True,"already_committed":True}
            self.prepared[tx]=dict(req, prepared_at=time.time())
            return {"prepared":True,"transaction_id":tx}
    def commit(self, tx):
        with self._lock:
            if tx in self.committed: return {"committed":True,"already_committed":True}
            if tx not in self.prepared: return {"committed":False,"error":"transaction not prepared"}
            self.committed[tx]=self.prepared.pop(tx)
            return {"committed":True,"transaction_id":tx}
    def abort(self, tx):
        with self._lock: self.prepared.pop(tx,None)
        return {"aborted":True,"transaction_id":tx}

ledger=Ledger()
def handle(c):
    try:
        b=b""
        while b"\n" not in b:
            x=c.recv(4096)
            if not x: break
            b+=x
        if not b:return
        r=json.loads(b.split(b"\n",1)[0].decode()); typ=r.get("type")
        if typ=="TX_PREPARE": out=ledger.prepare(r)
        elif typ=="TX_COMMIT": out=ledger.commit(r["transaction_id"])
        elif typ=="TX_ABORT": out=ledger.abort(r["transaction_id"])
        elif typ=="LEDGER_STATS": out={"prepared":len(ledger.prepared),"committed":len(ledger.committed)}
        else: out={"error":"unknown type"}
        c.sendall((json.dumps(out)+"\n").encode())
    except Exception as e:
        try:c.sendall((json.dumps({"error":str(e)})+"\n").encode())
        except Exception:pass
    finally:c.close()

def main():
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM); s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); s.bind((LEDGER_HOST,LEDGER_PORT)); s.listen(100)
    print(f"LEDGER NODE running on {LEDGER_HOST}:{LEDGER_PORT} PID={os.getpid()}")
    while True: threading.Thread(target=handle,args=(s.accept()[0],),daemon=True).start()
if __name__=="__main__": main()
