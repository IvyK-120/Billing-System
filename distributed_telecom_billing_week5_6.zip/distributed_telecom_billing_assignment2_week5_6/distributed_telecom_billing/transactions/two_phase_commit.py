import csv, os, time, uuid
from common.communication import send_json
from common.config import LEDGER_HOST, LEDGER_PORT, REQUEST_TIMEOUT, RATING_NODES, ACTIVE_RATING_NODES

class TwoPhaseCommitCoordinator:
    def __init__(self, csv_path=None):
        self.csv_path = csv_path or os.path.join("results", "week5_transactions.csv")
        os.makedirs(os.path.dirname(self.csv_path), exist_ok=True)
        if not os.path.exists(self.csv_path):
            with open(self.csv_path, "w", newline="") as f:
                csv.writer(f).writerow(["timestamp","transaction_id","customer_id","rating_node","prepare_ms","commit_ms","total_ms","status","failure"])

    def _log(self, row):
        with open(self.csv_path, "a", newline="") as f: csv.writer(f).writerow(row)

    def execute(self, request, rating_node=None, inject_failure=False):
        txid = request.get("transaction_id") or f"TX-{uuid.uuid4().hex[:12].upper()}"
        request = dict(request, transaction_id=txid)
        rating_node = rating_node or ACTIVE_RATING_NODES[0]
        rating_addr = RATING_NODES[rating_node]
        participants = [(rating_node, rating_addr), ("LEDGER", (LEDGER_HOST, LEDGER_PORT))]
        t0 = time.perf_counter(); prepared=[]; failure=""
        try:
            rating_resp = send_json(*rating_addr, {"type":"TX_PREPARE", **request}, timeout=REQUEST_TIMEOUT)
            if not rating_resp.get("prepared"): raise RuntimeError(f"{rating_node} rejected PREPARE")
            charge = rating_resp["charge"]; prepared.append(rating_node)
            ledger_resp = send_json(LEDGER_HOST, LEDGER_PORT, {"type":"TX_PREPARE","transaction_id":txid,"customer_id":request["customer_id"],"charge":charge,"service":request["service"],"usage":request["usage"]}, timeout=REQUEST_TIMEOUT)
            if not ledger_resp.get("prepared"): raise RuntimeError("LEDGER rejected PREPARE")
            prepared.append("LEDGER")
        except Exception as exc:
            failure=str(exc)
            for name,addr in participants:
                if name in prepared:
                    try: send_json(*addr,{"type":"TX_ABORT","transaction_id":txid},timeout=1.0)
                    except Exception: pass
            total_ms=(time.perf_counter()-t0)*1000
            self._log([time.time(),txid,request["customer_id"],rating_node,"","",round(total_ms,3),"ABORT",failure])
            return {"transaction_id":txid,"status":"ABORT","error":failure,"charge":None}
        prepare_ms=(time.perf_counter()-t0)*1000
        if inject_failure:
            failure="Injected coordinator failure between PREPARE and COMMIT"
            for _,addr in participants:
                try: send_json(*addr,{"type":"TX_ABORT","transaction_id":txid},timeout=1.0)
                except Exception: pass
            total_ms=(time.perf_counter()-t0)*1000
            self._log([time.time(),txid,request["customer_id"],rating_node,round(prepare_ms,3),"",round(total_ms,3),"ABORT",failure])
            return {"transaction_id":txid,"status":"ABORT","error":failure,"charge":charge}
        t_commit=time.perf_counter()
        try:
            for name,addr in participants:
                resp=send_json(*addr,{"type":"TX_COMMIT","transaction_id":txid},timeout=REQUEST_TIMEOUT)
                if not resp.get("committed"): raise RuntimeError(f"{name} failed COMMIT")
        except Exception as exc:
            failure=str(exc); commit_ms=(time.perf_counter()-t_commit)*1000; total_ms=(time.perf_counter()-t0)*1000
            self._log([time.time(),txid,request["customer_id"],rating_node,round(prepare_ms,3),round(commit_ms,3),round(total_ms,3),"IN_DOUBT",failure])
            return {"transaction_id":txid,"status":"IN_DOUBT","error":failure,"charge":charge}
        commit_ms=(time.perf_counter()-t_commit)*1000; total_ms=(time.perf_counter()-t0)*1000
        self._log([time.time(),txid,request["customer_id"],rating_node,round(prepare_ms,3),round(commit_ms,3),round(total_ms,3),"COMMIT",""])
        return {"transaction_id":txid,"status":"COMMIT","charge":charge,"rating_node":rating_node,"prepare_ms":round(prepare_ms,3),"commit_ms":round(commit_ms,3),"total_ms":round(total_ms,3)}
