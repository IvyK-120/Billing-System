import os, sys, time, json
PROJECT_ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:sys.path.insert(0,PROJECT_ROOT)
from common.communication import send_json
from common.config import NODE_HOST, NODE2_PORT, LEDGER_HOST, LEDGER_PORT

def tx(i, inject_failure=False):
    req={"type":"TX_BILL","request_id":i,"customer_id":f"C{1000+i}","service":"data","usage":10+i%20,"inject_failure":inject_failure}
    t=time.perf_counter(); r=send_json(NODE_HOST,NODE2_PORT,req,timeout=10); r["client_ms"]=round((time.perf_counter()-t)*1000,3); return r

def main():
    print("="*70); print("WEEK 5 — TWO-PHASE COMMIT"); print("="*70)
    for i in range(1,6): print(json.dumps(tx(i),indent=2))
    print("\nControlled abort:"); print(json.dumps(tx(99,True),indent=2))
    stats = send_json(LEDGER_HOST, LEDGER_PORT, {"type":"LEDGER_STATS"})
    print(f"\nLedger: {stats}")

if __name__=="__main__":main()
