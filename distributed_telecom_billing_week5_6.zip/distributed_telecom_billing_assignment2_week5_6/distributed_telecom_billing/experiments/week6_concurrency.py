import os
import sys
import threading
import time
import csv

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from concurrency.resource_manager import ResourceManager


rm = ResourceManager()

results = []

first_lock_barrier = threading.Barrier(2)
second_request_barrier = threading.Barrier(2)

deadlock_detected = threading.Event()
victim = None


def transfer(txid, first, second):

    global victim

    start = time.perf_counter()

    # -------------------------------------------------
    # PHASE 1
    # -------------------------------------------------

    got1 = rm.acquire(txid, first, timeout=1.0)

    if not got1:

        results.append((
            txid,
            "TIMEOUT_FIRST",
            round((time.perf_counter() - start) * 1000, 2)
        ))

        return

    print(f"{txid} acquired {first}")

    # Ensure both transactions own their first resource.
    first_lock_barrier.wait()

    print(f"{txid} requesting {second}")

    # Register the request before attempting to acquire.
    with rm.meta_lock:
        rm.waiting[txid].add(second)

    # Ensure both transactions have registered their
    # second-resource request.
    second_request_barrier.wait()

    # -------------------------------------------------
    # DEADLOCK DETECTION
    # -------------------------------------------------

    graph = rm.wait_for_graph()

    print(f"{txid} sees wait-for graph: {graph}")

    if rm.has_cycle(graph):

        deadlock_detected.set()

        # Deterministically choose TX-B as victim.
        with rm.meta_lock:
            if victim is None:
                victim = "TX-B"

        if victim == txid:

            print(f"{txid} selected as deadlock victim")

            with rm.meta_lock:
                rm.waiting[txid].discard(second)

            rm.release(txid, first)

            results.append((
                txid,
                "ABORTED_DEADLOCK",
                round((time.perf_counter() - start) * 1000, 2)
            ))

            return

    # -------------------------------------------------
    # CONTINUE WAITING FOR RESOURCE
    # -------------------------------------------------

    deadline = time.perf_counter() + 1.0

    while time.perf_counter() < deadline:

        if deadlock_detected.is_set() and victim == txid:
            return

        acquired = rm.locks[second].acquire(blocking=False)

        if acquired:

            with rm.meta_lock:
                rm.waiting[txid].discard(second)
                rm.owner[second] = txid

            print(f"{txid} acquired {second}")

            rm.release(txid, second)
            rm.release(txid, first)

            results.append((
                txid,
                "COMPLETED_AFTER_RECOVERY",
                round((time.perf_counter() - start) * 1000, 2)
            ))

            return

        time.sleep(0.01)

    # Safety timeout
    with rm.meta_lock:
        rm.waiting[txid].discard(second)

    rm.release(txid, first)

    results.append((
        txid,
        "RECOVERY_TIMEOUT",
        round((time.perf_counter() - start) * 1000, 2)
    ))


def main():

    print("=" * 70)
    print("WEEK 6 — CONCURRENCY / DEADLOCK EXPERIMENT")
    print("=" * 70)

    a = threading.Thread(
        target=transfer,
        args=("TX-A", "ACCOUNT-A", "ACCOUNT-B")
    )

    b = threading.Thread(
        target=transfer,
        args=("TX-B", "ACCOUNT-B", "ACCOUNT-A")
    )

    a.start()
    b.start()

    a.join()
    b.join()

    print("\nRESULTS")
    print("-" * 70)

    for result in results:
        print(result)

    print("\nFinal wait-for graph:")
    print(rm.wait_for_graph())

    os.makedirs("results", exist_ok=True)

    with open(
        "results/week6_concurrency.csv",
        "w",
        newline=""
    ) as f:

        writer = csv.writer(f)

        writer.writerow([
            "transaction",
            "result",
            "duration_ms"
        ])

        writer.writerows(results)


if __name__ == "__main__":
    main()